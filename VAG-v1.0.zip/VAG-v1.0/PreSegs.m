function [objmsk,nobj]=PreSegs(mmsk)

ridx = unique(mmsk);
objmsk = zeros(size(mmsk));
sk = 1;
for k =1:length(unique(mmsk))
        bmsk = mmsk==ridx(k);
        conregions = bwlabel(bmsk);

        segidx = unique(conregions);
        if length(segidx)==1
            continue;
        elseif length(segidx)==2
            if length(find(conregions==segidx(2)))<50, continue; end
            objmsk(conregions==segidx(2)) = sk;
            sk = sk+1;
        elseif length(segidx)>2
            for j=1:length(segidx)-1
                if length(find(conregions==segidx(j+1)))<50, continue; end
                objmsk(conregions==segidx(j+1)) = sk;
                sk = sk+1;
            end
        end
end
nobj = length(unique(objmsk));
