function ShowRawScan(img,fixdata,imcoor)
% Visualisation

figure;imshow(img,[]);

if imcoor % [row,column]
    yy = fixdata.fix_x;  % row
    xx = fixdata.fix_y;  % column
else  % fix-coor: [column,y-row]
    xx = fixdata.fix_x;  % column
    yy = fixdata.fix_y;  % row
end

hold on; plot(floor(xx),floor(yy),'LineWidth',3,'Color',[1 0 0]);  % [column, row]
for i=1:length(xx)
    hold on; text(floor(xx(i)),floor(yy(i)),num2str(i),...
        'BackgroundColor',[1 0 0],'FontWeight','bold','FontSize',14,'Color',[1 1 1]);
end