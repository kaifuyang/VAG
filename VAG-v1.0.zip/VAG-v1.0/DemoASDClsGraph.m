% Demo scanpath 
clear; clc;

task = 'ASD'; % {TD, ASD};

DataPath = ['./ASDscreening/' task '/'];  % path to fixations
impath = './ASDscreening/Images/';    % path to images 
segpath = './ASDscreening/LabelSeg';  % path to labelled segments

scanpath = ['./ASDscreening/scangraph/' task '/']; % path to save Attention Graph (object)
if ~exist(scanpath, 'dir'),mkdir(scanpath);end

files = dir(fullfile(impath,'*.png'));
for i = 1:length(files)
    % reading image
    fprintf(2,'Processing image %d/%d...\n',i,length(files));
    
    iid = files(i).name;
    iim = iid(1:end-4);
    
    img = imread(fullfile(impath,iid));
    [hh,ww,dd]=size(img);
    
    segs = load([segpath '/' iid(1:end-4) '.mat']);
    [objmsk,nobj]=PreSegs(segs.msk.objmsk);  % objmsk

    %=========================================================================%
    datafix = importdata([DataPath,task,'_scanpath_',iim,'.txt']);
    allfix = datafix.data;
    fixdata = gettaskfix(allfix);
    [SemSal_fix,SemSal_all] = getSemSalfromFix_nodur(objmsk,fixdata,nobj);

    [allScans,adjM,ScoreGraph] = CreateScanGraph(objmsk,fixdata,nobj);

    % save all data 
    gt.allScans = allScans;
    gt.adjM = adjM;
    gt.ScoreGraph = ScoreGraph;
    gt.SemSal_fix = SemSal_fix;
    gt.SemSal_all = SemSal_all;
    gt.objmsk = objmsk;
    save([scanpath,iid(1:end-4), '.mat'], 'gt')

end


%=========================================================================%
