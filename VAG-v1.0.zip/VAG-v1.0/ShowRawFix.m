function ShowRawFix(img,fixdata)
% Visualisation

figure;imshow(img,[]);

[hh,ww,dd] = size(img);
nsub = length(fixdata.subjects);

fixdis = zeros(hh,ww);

for j=1:nsub
    subfix = fixdata.subjects{j,1};   % [column,row]
    % check fixations
    if sum(subfix.fix_y>hh)>0 | sum(subfix.fix_y<=0)>0 | sum(subfix.fix_x>ww)>0 |  sum(subfix.fix_x<=0)>0
        continue;
    end
    for ii=1:length(subfix.fix_x)
        hold on; plot(floor(subfix.fix_x(ii)),floor(subfix.fix_y(ii)),'bs','LineWidth',3,'MarkerSize',5);
        fixdis(floor(subfix.fix_y(ii)), floor(subfix.fix_x(ii)))=1;
    end
end

% show fixation density
% hgaus = fspecial('gaussian',[10 10],2);
% fixdis = imfilter(fixdis,hgaus);
% figure;imshow(fixdis,[]);

hgaus = fspecial('gaussian',[200 200],30);
fixdis = imfilter(fixdis,hgaus);
figure;imshow(fixdis,[]);
