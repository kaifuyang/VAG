function fixdata = gettaskfix(allfix)

idx = allfix(:,1);
tix = find(idx==0);
tix = [tix;length(idx)+1];
for k=1:length(tix)-1
        ttx = allfix(tix(k):tix(k+1)-1,2);
        tty = allfix(tix(k):tix(k+1)-1,3);
        fixdata.subjects{k,1}.fix_x = ttx';
        fixdata.subjects{k,1}.fix_y = tty';
end
