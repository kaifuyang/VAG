function [SemSal_fix,SemSal_all]= getSemSalfromFix_nodur(objmsk,fixdata,nobj)
% Create Semantic Salieny

nsub = length(fixdata.subjects);
[hh,ww] = size(objmsk);

SemSal_fix = zeros(1,nobj);
SemSal_all = zeros(nsub,nobj);

for j=6:nsub
    subfix = fixdata.subjects{j,1};  % read the fixations   %  [column, row]
    
    % check fixations
    if sum(subfix.fix_y>hh)>0 | sum(subfix.fix_y<1)>0 | sum(subfix.fix_x>ww)>0 |  sum(subfix.fix_x<1)>0
        continue;
    end
    
    for ii=1:length(subfix.fix_x)
        
        tidx = objmsk(floor(subfix.fix_y(ii)),floor(subfix.fix_x(ii)));  % tidx - [row,column]

        % correct fixations near objects (within 30 pixels)
        if tidx==0  % background point
            fxy = [floor(subfix.fix_y(ii)),floor(subfix.fix_x(ii))]; % fxy - [row,column]
            tmsk = zeros(size(objmsk));
            tmsk(fxy(1),fxy(2))=1;
            se = strel('disk',30);
            tmsk=imdilate(tmsk,se); 
            idxmsk = objmsk.*tmsk;
            idx = unique(idxmsk(:));
            if length(idx)>1
                idx(idx==0)=[];
                dis = zeros(length(idx),1);
                for jj=1:length(idx)
                    [oxx,oyy]= find(idxmsk==idx(jj));
                    oxy =[oxx';oyy'];
                    tempdis = min(sqrt(sum((fxy'-oxy).^2)));
                    dis(jj) = tempdis(1);
                end
                mindis = min(dis);
                tidx = idx(dis==mindis(1));
                tidx = tidx(1);
            end           
        end
        
        if tidx~=0
            SemSal_fix(tidx) = SemSal_fix(tidx) + 1;
        end
    end
    SemSal_all(j,:)=SemSal_fix; 
    SemSal_fix = zeros(1,nobj);
end

% idx = find(sum(SemSal_all,2)==0);
% SemSal_all(idx,:)=[];

SemSal_fix = sum(SemSal_all,1);
SemSal_fix = SemSal_fix./sum(SemSal_fix);





