function fixdata = getmosfix(allfix,iim,mos)
group = allfix.groups;
gidx = strcmp(group,mos);

k=1;
for i=1:41
    if gidx(i)
        fix = allfix.fixations{i,iim};
        if ~isempty(fix)
            fixdata.subjects{k,1}.fix_x = allfix.fixations{i,iim}(1,:);
            fixdata.subjects{k,1}.fix_y = allfix.fixations{i,iim}(2,:);
            k=k+1;
        else
            fixdata.subjects{k,1}.fix_x = [];
            fixdata.subjects{k,1}.fix_y = [];
            k=k+1;
        end
    end
end
end