function   [allScans,adjM,ScoreGraph,SemSal_fix,SemSal_all,semmsk] = GenSemScanGraph(objScans,semfeats,Sal_fix,Sal_all,objmsk)

for ii = 1:length(semfeats)
    tidx(ii) = sum(semfeats{ii})+sum(find(semfeats{ii}==1));
end

sems = unique(tidx);
nsem = length(sems);
idx = zeros(size(tidx));

for i=1:nsem
    idx(tidx==sems(i))=i;
    SemSal_fix(i) = sum(Sal_fix(tidx==sems(i)));
end

semmsk=zeros(size(objmsk));
for i=1:nsem
    ttid = find(idx==i);
    for j=1:length(ttid)
       semmsk(objmsk==ttid(j))=i;
    end
end

for k=1:size(Sal_all,1)
    for i=1:nsem
        SemSal_all(k,i) = sum(Sal_all(k,tidx==sems(i)));
    end
end

adjM = zeros(nsem);

for j = 1:length(objScans)
    tscan = objScans{j};
    if isempty(tscan)
       allScans{j,1}=[];
       continue;
    end
    idx0 =idx(tscan(1));
    slist = idx0;
    for k=2:length(tscan)
        if(idx(tscan(k))==idx0)
            continue;
        else
            slist = [slist idx(tscan(k))];
            if length(slist)>1
                adjM(idx0,idx(tscan(k)))=adjM(idx0,idx(tscan(k)))+1;
            end
            idx0 = idx(tscan(k));
        end
    end
    % for the trail without path
    if length(slist)==1
        adjM(slist,slist)=adjM(slist,slist)+1;
        slist = [slist,slist];
    end
    allScans{j,1}=slist;
end

adjM(isnan(adjM))=0;

ScoreGraph = adjM./repmat(max(adjM,[],2),[1,nsem]);
ScoreGraph(isnan(ScoreGraph))=0;
