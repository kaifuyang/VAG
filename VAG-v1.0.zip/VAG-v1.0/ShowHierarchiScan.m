function ShowHierarchiScan(img,objmsk,objcxy,fixdata,scan,imcoor)
    
% Visualisation

if imcoor % x-row; y-column
    yy = fixdata.fix_x;  % row
    xx = fixdata.fix_y;  % column
else  % fix-coor: x-column; y-row
    xx = fixdata.fix_x;  % column
    yy = fixdata.fix_y;  % row
end

figure;imshow(img,[]);
for i=1:length(xx)
    if i>1
        hold on; plot([floor(xx(i-1)),floor(xx(i))], [floor(yy(i-1)),floor(yy(i))],'LineWidth',3,'Color',[0 0 1]); % [column, row]
    end
end
for i=1:length(xx)
    hold on; text(floor(xx(i)),floor(yy(i)),num2str(i),...
        'BackgroundColor',[0 0 1],'FontWeight','bold','FontSize',14,'Color',[1 1 1]);
end

%==========================================================================%
Seqlist = ['A' 'B' 'C' 'D' 'E' 'F' 'G' 'H' 'I' 'J' 'K' 'L' 'M' 'N' ...
           'O' 'P' 'Q' 'R' 'S' 'T' 'U' 'V' 'W' 'X' 'Y' 'Z' ... 
           'a' 'b'  'c' 'd' 'e' 'f' 'g' 'h' 'i' 'j' 'k' 'l' 'm' ...
           'n' 'o' 'p' 'q' 'r' 's' 't' 'u' 'v' 'w' 'x' 'y' 'z'...
           'aa' 'bb'  'cc' 'dd' 'ee' 'ff' 'gg' 'hh' 'ii' 'jj' 'kk' 'll' 'mm' ...
           'nn' 'oo' 'pp' 'qq' 'rr' 'ss' 'tt' 'uu' 'vv' 'ww' 'xx' 'yy' 'zz'];

xi = []; yi=[];
for j=1:length(scan)
    xy = objcxy{scan(j),1};
    xi = [xi xy(1)]; yi = [yi xy(2)];
    label{j}=Seqlist(scan(j));
end

figure;imshow(objmsk,[]);
for j=1:length(xi)
    if j>1
        hold on; plot([floor(xi(j-1)),floor(xi(j))], [floor(yi(j-1)),floor(yi(j))],'LineWidth',3,'Color',[1 0 0]);
    end
end
for j=1:length(xi)
    hold on; text(floor(xi(j)),floor(yi(j)),label{j},...
        'BackgroundColor',[1 0 0],'FontWeight','bold','FontSize',14,'Color',[1 1 1]);
end

% for k=1:length(objcxy)
%     xy = objcxy(k,1);
%     label{k}=Seqlist(k);
%     hold on; text(floor(xy{1}(1)),floor(xy{1}(2)),label{k},...
%         'BackgroundColor',[1 0 0],'FontWeight','bold','FontSize',14,'Color',[1 1 1]);
% end

