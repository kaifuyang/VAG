% clear;clc;

datapath = './OSIE/data/'; % path to save OSIE dataset 
group = '30mos'; % 18mos  30mos  

impath = './AgeClass/data/images';
allfixdata = load('./AgeClass/data/processed/fixations/data.mat'); % path to processed fixations

objpath = ['./AgeClass/data/processed/objgraph/' group '/'];    % path to save Attention Graph (object)
sempath = ['./AgeClass/data/processed/semgraph/' group '/'];    % path to save Attention Graph (Attribute)

% load all data
atts = load([datapath,'attrs.mat']);

files = dir(fullfile(impath,'*.jpg'));
for i = 1:length(files)
    % reading image
    fprintf(2,'Processing image %d/%d...\n',i,length(files));
    
    iid = files(i).name; 
    for j = 1:length(atts.attrs)
        if strcmp(atts.attrs{j,1}.img,iid)
            iim = j;
        end
    end
    
    img = imread(fullfile(impath,iid));
    [hh,ww,dd]=size(img);
    
    % objects' segments on the current image
    nobj = length(atts.attrs{iim,1}.objs);
   
    obj.msk = cell(nobj,1);
    obj.name = cell(nobj,1);
    obj.feats = cell(nobj,1);
    objmsk = zeros(hh,ww);
    tmsk = zeros(hh,ww);
    for k=1:nobj
        obj.feats{k,1} = atts.attrs{iim,1}.objs{k,1}.features;
        obj.msk{k,1} = atts.attrs{iim,1}.objs{k,1}.map;
        tcxy = regionprops(obj.msk{k,1},'Centroid');
        obj.cxy{k,1} = tcxy.Centroid;  % [column,row]
        obj.name{k,1} = k;
        
        % overlap regions
        temp = obj.msk{k,1} & tmsk;
        if sum(sum(temp - obj.msk{k,1}))<100
            objmsk(obj.msk{k,1}==1)=k;
        else
            objmsk(obj.msk{k,1}==1 & tmsk==0)=k;
        end
        tmsk = tmsk | obj.msk{k,1};
    end

%=========================================================================%
    fixdata = getmosfix(allfixdata,i,group); % 18mos  30mos  
    [SemSal_fix,SemSal_all] = getSemSalfromFix_nodur(objmsk,fixdata,nobj);

    [allScans,adjM,ScoreGraph] = CreateScanGraph(objmsk,fixdata,nobj);

    % save all data 
    gt.allScans = allScans;
    gt.adjM = adjM;
    gt.ScoreGraph = ScoreGraph;
    gt.SemSal_fix = SemSal_fix;
    gt.SemSal_all = SemSal_all;
    gt.objmsk = objmsk;
    save([objpath,iid(1:end-4), '.mat'], 'gt')
    
%=========================================================================%
%     [allScans,adjM,ScoreGraph,SemSal_fix,SemSal_all,semmsk] = GenSemScanGraph(allScans,obj.feats,SemSal_fix,SemSal_all,objmsk);

%     % save all data 
%     gt.allScans = allScans;
%     gt.adjM = adjM;
%     gt.ScoreGraph = ScoreGraph;
%     gt.SemSal_fix = SemSal_fix;
%     gt.SemSal_dur = SemSal_all;
%     gt.objmsk = semmsk;
%     save([sempath,iid(1:end-4), '.mat'], 'gt')
       
end
