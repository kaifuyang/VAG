% Demo scanpath 
clear;clc;

datapath = './OSIE/data/'; % path to save OSIE dataset 

objpath = './OSIE/OBJgraph/';  % path to save Attention Graph (object)
sempath = './OSIE/SEMgraph/';  % path to save Attention Graph (Attribute)

% load all data
atts = load([datapath,'attrs.mat']);  % load images and annotations
fixs = load([datapath,'eye/fixations.mat']); % load human fixations

for iim = 1:length(fixs.fixations)
    fprintf(2,'Processing image %d/%d...\n',iim,length(fixs.fixations)); 
    iid = fixs.fixations{iim,1}.img;
    
%=========================================================================%
    % reading image
    img = imread([datapath, 'stimuli/',iid]);
    [hh,ww,dd]=size(img);
    
    % objects' segments on the current image
    nobj = length(atts.attrs{iim,1}.objs);
    nsub = length(fixs.fixations{iim,1}.subjects);
    
    obj.msk = cell(nobj,1);
    obj.name = cell(nobj,1);
    obj.feats = cell(nobj,1);
    objmsk = zeros(hh,ww);
    tmsk = zeros(hh,ww);
    for k=1:nobj
        obj.feats{k,1} = atts.attrs{iim,1}.objs{k,1}.features;
        obj.msk{k,1} = atts.attrs{iim,1}.objs{k,1}.map;
        tcxy = regionprops(obj.msk{k,1},'Centroid');
        obj.cxy{k,1} = tcxy.Centroid;  % [column,row]
        obj.name{k,1} = k;
        
        % overlap regions
        temp = obj.msk{k,1} & tmsk;
        if sum(sum(temp - obj.msk{k,1}))<100
            objmsk(obj.msk{k,1}==1)=k;
        else
            objmsk(obj.msk{k,1}==1 & tmsk==0)=k;
        end
        tmsk = tmsk | obj.msk{k,1};
    end
    % figure; imshow(img,[]);
    % figure; imshow(objmsk,[]);
    
%=========================================================================%
%     % Create Saliency
    fixdata = fixs.fixations{iim,1};
    [SemSal_fix,SemSal_all] = getSemSalfromFix_nodur(objmsk,fixdata,nobj);
%     ShowRawFix(objmsk,fixdata)

%=========================================================================%
    % Create Object-based Attention Graph
    [allScans,adjM,ScoreGraph] = CreateScanGraph(objmsk,fixdata,nobj);
    
%     subb = 1;
%     ShowRawScan(objmsk,fixdata.subjects{subb,1},0); % show raw scanpath
%     ShowHierarchiScan(img,objmsk,obj.cxy,fixdata.subjects{subb,1},allScans{subb},0); % show hierarchical scans


%     % save all data 
%     gt.allScans = allScans;
%     gt.adjM = adjM;
%     gt.ScoreGraph = ScoreGraph;
%     gt.SemSal_fix = SemSal_fix;
%     gt.SemSal_all = SemSal_all;
%     gt.objmsk = objmsk;
%     save([objpath,iid(1:end-4), '.mat'], 'gt')

%=========================================================================%
%    % Create Attribute-based Attention Graph
%    [allScans,adjM,ScoreGraph,SemSal_fix,SemSal_all,semmsk] = GenSemScanGraph(allScans,obj.feats,SemSal_fix,SemSal_all,objmsk);
% 
%     % save all data 
%     gt.allScans = allScans;
%     gt.adjM = adjM;
%     gt.ScoreGraph = ScoreGraph;
%     gt.SemSal_fix = SemSal_fix;
%     gt.SemSal_all = SemSal_all;
%     gt.semmsk = semmsk;
%     save([sempath,iid(1:end-4), '.mat'], 'gt')

%=========================================================================%
%     % Attention Graph Visualisation
%     Seqlist = ['A' 'B' 'C' 'D' 'E' 'F' 'G' 'H' 'I' 'J' 'K' 'L' 'M' 'N' ...
%                'O' 'P' 'Q' 'R' 'S' 'T' 'U' 'V' 'W' 'X' 'Y' 'Z' ... 
%                'a' 'b'  'c' 'd' 'e' 'f' 'g' 'h' 'i' 'j' 'k' 'l' 'm' ...
%                'n' 'o' 'p' 'q' 'r' 's' 't' 'u' 'v' 'w' 'x' 'y' 'z'];
%     for ii = 1:size(adjM,1) 
%         Objlist{ii} = Seqlist(ii);
%     end
% 
%     % plot graph
%     G=digraph(adjM,Objlist);
%     figure;plot(G,'Layout','layered','EdgeLabel',G.Edges.Weight)
%     clear Objlist;
   
end

%=========================================================================%
