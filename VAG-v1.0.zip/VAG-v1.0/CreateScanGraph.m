function [allScans,adjM,ScoreGraph] = CreateScanGraph(objmsk,fixdata,nobj)
% Create Scan Graph - adjacent matrix

nsub = length(fixdata.subjects);

[hh,ww] = size(objmsk);

adjM = zeros(nobj,nobj);
allScans = cell(nsub,1);
for j=1:nsub
    subfix = fixdata.subjects{j,1};  % read the fixations  % [column,row]
    
    % check fixations
    if sum(subfix.fix_y>hh)>0 | sum(subfix.fix_y<1)>0 | sum(subfix.fix_x>ww)>0 |  sum(subfix.fix_x<1)>0
        continue;
    end

    flist = [];
    tidx0 = 0;
    for ii=1:length(subfix.fix_x)
        tidx = objmsk(floor(subfix.fix_y(ii)),floor(subfix.fix_x(ii)));  % tidx - [row,column]
        
        % correct fixations near objects (within 30 pixels)
        if tidx==0  % background point
            fxy = [floor(subfix.fix_y(ii)),floor(subfix.fix_x(ii))]; % fxy - [row,column]
            tmsk = zeros(size(objmsk));
            tmsk(fxy(1),fxy(2))=1;
            se = strel('disk',30);
            tmsk=imdilate(tmsk,se); 
            idxmsk = objmsk.*tmsk;
            idx = unique(idxmsk(:));
            if length(idx)>1
                idx(idx==0)=[];
                dis = zeros(length(idx),1);
                for jj=1:length(idx)
                    [oxx,oyy]= find(idxmsk==idx(jj));
                    oxy =[oxx';oyy'];
                    tempdis = min(sqrt(sum((fxy'-oxy).^2)));
                    dis(jj) = tempdis(1);
                end
                mindis = min(dis);
                tidx = idx(dis==mindis(1));
                tidx = tidx(1);
            end           
        end
        
        if tidx~= tidx0 & tidx~=0
           flist = [flist,tidx];
           if length(flist)>1
              adjM(tidx0,tidx) = adjM(tidx0,tidx)+1;
           end
              tidx0 = tidx;             
         end
    end
     
    % for the trail without path
    if length(flist)==1
        adjM(flist,flist)=adjM(flist,flist)+1;
        flist = [flist,flist];
    end
    allScans{j,1} = flist;
    
end

% allScans(cellfun(@isempty,allScans))=[]; 
adjM(isnan(adjM))=0;

ScoreGraph = adjM./repmat(max(adjM,[],2),[1,nobj]); 
ScoreGraph(isnan(ScoreGraph))=0;


