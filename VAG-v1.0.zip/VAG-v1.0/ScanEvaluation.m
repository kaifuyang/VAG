function score = ScanEvaluation(ScoreGraph,path,SemSal)

score = 0;

% for the trail without path
if length(path)==1
    path = [path,path];
    
end

Sweight = 0;
for i = 1:length(path)-1
    Sweight = Sweight + SemSal(path(i));
    score = score + ScoreGraph(path(i),path(i+1))*SemSal(path(i));
end

if Sweight==0
    score = 0;
else
    score = score/Sweight;
end
