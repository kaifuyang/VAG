% load all data
clear;
clc;

scan18 = './ASDscreening/scangraph/ASD/'; 
scan30 = './ASDscreening/scangraph/TD/';

files = dir(fullfile(scan18,'*.mat'));

allsocres0 = nan(28,length(files));
allsocres = nan(28,length(files));

for i = 1:length(files)
    iid = files(i).name;

    % scangraph-18mos
    load([scan18,iid(1:end-4), '.mat']);
    allScans18 = gt.allScans;
    adjM18 = gt.adjM;
    SSweight18 = gt.SemSal_fix;
    SemSal_fix18 = gt.SemSal_all;
    ScoreGraph18 = gt.ScoreGraph;
    
%===========GRAPH metrics======================%
    Gdgree18(i) = sum(adjM18(:));
    
    nobj = size(adjM18,1);
    
    % scangraph-30mos
    load([scan30,iid(1:end-4), '.mat']);
    allScans30 = gt.allScans;
    adjM30 = gt.adjM;
    SSweight30 = gt.SemSal_fix;
    SemSal_fix30 = gt.SemSal_all;
    ScoreGraph30 = gt.ScoreGraph;
    
    %===========GRAPH metrics======================%
    Gdgree30(i) = sum(adjM30(:));
   
    num_scan18 = length(allScans18);
    num_scan30 = length(allScans30);
    
    gtt = [ones(14,1);-1*ones(14,1)];
    
    testlen18=[];
    testlen30=[];
    
    % Scores
    lenpath = 0;
    for k=1:28
        if k<=num_scan18
            pathk = allScans18{k};
            if isempty(pathk)
                Scores(k,1) = nan;
                Scores(k,2) = nan;
                fixScores(k,1) = nan;
                fixScores(k,2) = nan;
            else
                testlen18 = [testlen18 length(pathk)];
                Scans = allScans18;  Scans(k)=[];  % removing the current path
                Scans(cellfun(@isempty,Scans))=[];
                [adjM18,ScoreGraph18]= Scan2Graph(Scans,nobj);
                
                SSweight = ones(1,nobj); % without SemSal weights
                Scores(k,1) = ScanEvaluation(ScoreGraph18,pathk,SSweight); % SSweight18
                Scores(k,2) = ScanEvaluation(ScoreGraph30,pathk,SSweight); % SSweight30
            end
            
        elseif k>num_scan18 && k<=14
            Scores(k,1) = nan;
            Scores(k,2) = nan;
            fixScores(k,1) = nan;
            fixScores(k,2) = nan;
            
        elseif k>14 && k<=14+num_scan30
            pathk = allScans30{k-14};
            if isempty(pathk)
                Scores(k,1) = nan;
                Scores(k,2) = nan;
                fixScores(k,1) = nan;
                fixScores(k,2) = nan;
            else
                testlen30 = [testlen30 length(pathk)];
                Scans = allScans30;  Scans(k-14)=[];  % removing the current path
                Scans(cellfun(@isempty,Scans))=[];
                [adjM30,ScoreGraph30]= Scan2Graph(Scans,nobj);
                
                SSweight = ones(1,nobj); % without SemSal weights
                Scores(k,1) = ScanEvaluation(ScoreGraph18,pathk,SSweight); % SSweight18
                Scores(k,2) = ScanEvaluation(ScoreGraph30,pathk,SSweight); % SSweight30
                
            end
        elseif k>14+num_scan30
            Scores(k,1) = nan;
            Scores(k,2) = nan;
            fixScores(k,1) = nan;
            fixScores(k,2) = nan;
        end
        
    end
    coms0 = Scores(:,1) - Scores(:,2);
    allsocres(:,i) = coms0;
    clear fixScores Scores;
end

% plot  boxchart
[h2,p2,ci2]=ttest2(Gdgree18',Gdgree30');
figure; b1 = boxchart([Gdgree18' nan(size(Gdgree18'))]);
hold on; b2 = boxchart([nan(size(Gdgree30')) Gdgree30']);
b1.Notch = 'on'; b2.Notch = 'on';
b1.LineWidth = 2; b2.LineWidth = 2;

allsocres(isnan(allsocres))=0;


for kk = 1:28
    cc(kk) = length(find(allsocres(kk,:)>0))-length(find(allsocres(kk,:)<0));
end
tcc = sum(allsocres,2);
cc(cc==0) = tcc(cc==0);

cc(cc>0)=1;
cc(cc<0)=-1;
acc = sum(gtt==cc')/28;
acc

