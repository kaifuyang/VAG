function [adjM,ScoreGrpah]= Scan2Graph(Scans,nobj)

nsub = length(Scans);
adjM = zeros(nobj,nobj);

for k=1:nsub
    pathk = Scans{k};
    for i = 1:length(pathk)-1
        adjM(pathk(i),pathk(i+1)) = adjM(pathk(i),pathk(i+1))+1;
    end
end
adjM(isnan(adjM))=0;

ScoreGrpah = adjM./repmat(max(adjM,[],2),[1,nobj]); 
ScoreGrpah(isnan(ScoreGrpah))=0;