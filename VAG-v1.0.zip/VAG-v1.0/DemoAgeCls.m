% load all data
clear;
clc;
scan18 = './AgeClass/data/processed/semgraph/18mos/';  
scan30 = './AgeClass/data/processed/semgraph/30mos/';
impath = './AgeClass/data/images';

files = dir(fullfile(impath,'*.jpg'));

L18 = []; L30 = [];

for i = 1:length(files)
    iid = files(i).name;
    
    % scangraph-18mos
    load([scan18,iid(1:end-4), '.mat']);
    allScans18 = gt.allScans;
    adjM18 = gt.adjM;
    SSweight18 = gt.SemSal_fix;
    SemSal_fix18 = gt.SemSal_all;
    ScoreGraph18 = gt.ScoreGraph;
    
%===========GRAPH metrics======================%
    Gdgree18(i) = sum(adjM18(:));
    
%===========GRAPH metrics======================%

    nobj = size(adjM18,1);
    
    % scangraph-30mos
    load([scan30,iid(1:end-4), '.mat']);
    allScans30 = gt.allScans;
    adjM30 = gt.adjM;
    SSweight30 = gt.SemSal_fix;
    SemSal_fix30 = gt.SemSal_all;
    ScoreGraph30 = gt.ScoreGraph;
    
%===========GRAPH metrics======================%
   Gdgree30(i) = sum(adjM30(:));
   
%===========GRAPH metrics======================% 

    num_scan18 = length(allScans18);
    num_scan30 = length(allScans30);
    
    gtt = [ones(num_scan18,1);-1*ones(num_scan30,1)];
    
    testlen18=[];
    testlen30=[];
    
    % Scores
    lenpath = 0;
    for k=1:num_scan18+num_scan30
        
        if k<=num_scan18
            pathk = allScans18{k};
            if isempty(pathk)
                Scores(k,1) = nan;
                Scores(k,2) = nan;
                fixScores(k,1) = nan;
                fixScores(k,2) = nan;
            else
                Scans = allScans18;  Scans(k)=[];  % removing the current path
                Scans(cellfun(@isempty,Scans))=[];
                [adjM18,ScoreGraph18]= Scan2Graph(Scans,nobj);
                
%                 SSweight = ones(1,nobj); % without weights
                Scores(k,1) = ScanEvaluation(ScoreGraph18,pathk,SSweight18); % SSweight18
                Scores(k,2) = ScanEvaluation(ScoreGraph30,pathk,SSweight30); % SSweight30

                testlen18 = [testlen18 length(pathk)];
  
            end
            
        elseif k>num_scan18
            pathk = allScans30{k-num_scan18};
            if isempty(pathk)
                Scores(k,1) = nan;
                Scores(k,2) = nan;
                fixScores(k,1) = nan;
                fixScores(k,2) = nan;
            else
                Scans = allScans30;  Scans(k-num_scan18)=[];  % removing the current path
                Scans(cellfun(@isempty,Scans))=[];
                [adjM30,ScoreGraph30]= Scan2Graph(Scans,nobj);
                
%                 SSweight = ones(1,nobj); % without weights
                Scores(k,1) = ScanEvaluation(ScoreGraph18,pathk,SSweight18); % SSweight18
                Scores(k,2) = ScanEvaluation(ScoreGraph30,pathk,SSweight30); % SSweight30

                testlen30 = [testlen30 length(pathk)];                
                
            end
        end
        
    end
    
    L18 = [L18 testlen18];
    L30 = [L30 testlen30];

    allcoms1(:,i) = Scores(:,1);
    allcoms2(:,i) = Scores(:,2);
    allsocres(:,i) = Scores(:,1) - Scores(:,2);
end

% plot 
[h,p,ci]=ttest2(L18',L30');
[h2,p2,ci2]=ttest2(Gdgree18',Gdgree30');

figure; a1 = boxchart([L18' nan(size(L18'))]);
hold on; a2 = boxchart([nan(size(L30')) L30']);   
a1.Notch = 'on'; a2.Notch = 'on';
a1.LineWidth = 2; a2.LineWidth = 2;

figure; b1 = boxchart([Gdgree18' nan(size(Gdgree18'))]);
hold on; b2 = boxchart([nan(size(Gdgree30')) Gdgree30']);
b1.Notch = 'on'; b2.Notch = 'on';
b1.LineWidth = 2; b2.LineWidth = 2;
%==========================================================================%
allsocres = allsocres;
allsocres(isnan(allsocres))=0;

for kk = 1:41
    cc(kk) = length(find(allsocres(kk,:)>0))-length(find(allsocres(kk,:)<0));  % vote
end
tcc = sum(allsocres,2);
cc(cc==0) = tcc(cc==0);

cc(cc>0)=1;
cc(cc<0)=-1;
acc = sum(gtt==cc')/41;
acc
